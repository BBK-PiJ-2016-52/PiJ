message = new javafx.scene.control.Label("Hello, JavaFX!")
message.setFont(new javafx.scene.text.Font(100))
stage.setScene(new javafx.scene.Scene(message))
stage.setTitle("Hello")
stage.show();
