public @interface TestCases {
   TestCase[] value();
}
